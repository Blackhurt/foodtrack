const data = [
    {
        "name": "Hamburger",
        "price": "200",
        "image": "burger.jpeg"
    },
    {
        "name": "Fries",
        "price": "100",
        "image": "fries.jpeg"
    },
    {
        "name": "Coke",
        "price": "50",
        "image": "coke.jpeg"
    },
    {
        "name": "Pepsi",
        "price": "50",
        "image": "pepsi.jpeg"
    }
]

export default data;