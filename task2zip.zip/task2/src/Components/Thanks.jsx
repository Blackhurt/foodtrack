import "../Components/Thanks.css"
const Thanks = () =>{

    return(<>
    <div className="thanks-main">
        <div className="thanks-card">
            <h1>checkout</h1>
            <p>Thank you for your order. </p>
        </div>
    </div>
    </>)
};

export default Thanks;